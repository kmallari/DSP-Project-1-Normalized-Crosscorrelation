crosscorrelation-example.ods 
shows how the crosscorrelation of the signals
x (from signal-1.txt)
and
y (from signal-2.txt)
are computed.

starting-l.png shows computation for start index of crosscorrelation